package mainpackage;

public class success {
	public static void main(String[] args) {
		System.out.println("go a head ");
		JDBCHandling db = new JDBCHandling();
	}

}
	